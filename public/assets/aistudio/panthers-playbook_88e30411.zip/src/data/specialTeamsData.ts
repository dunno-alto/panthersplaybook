export type SpecialTeamsUnitId = 'kickoff' | 'kick_return' | 'punt_coverage' | 'punt_return' | 'fg_pat' | 'fg_block';

export interface STPlayer {
  id: string;
  label: string;
  name: string;
  role: string;
  x: number;
  y: number;
  responsibility: string;
  coachingCue: string;
}

export interface SpecialTeamsUnit {
  id: SpecialTeamsUnitId;
  name: string;
  shortName: string;
  targetTempo: string;
  overview: string;
  coachingMotto: string;
  schemeOptions: { id: string; label: string }[];
  players: STPlayer[];
  rulesAndDrills: { title: string; rule: string }[];
}

export const SPECIAL_TEAMS_PLAYBOOK: Record<SpecialTeamsUnitId, SpecialTeamsUnit> = {
  kickoff: {
    id: 'kickoff',
    name: 'Kickoff Coverage Unit',
    shortName: 'Kickoff',
    targetTempo: '4.1s Hangtime',
    overview: 'Disciplined lane integrity is non-negotiable. 5 left, Kicker safety valve, 5 right.',
    coachingMotto: 'Stay in your lane, fold inside-out.',
    schemeOptions: [{ id: 'kickoff_right', label: 'Kickoff Right' }, { id: 'kickoff_left', label: 'Kickoff Left' }],
    players: [
      { id: 'L5', label: 'L5', name: 'Left Contain', role: 'Contain', x: 120, y: 520, responsibility: 'Outside contain', coachingCue: 'Squeeze sideline' },
      { id: 'K', label: 'K', name: 'Kicker', role: 'Safety Valve', x: 500, y: 560, responsibility: 'Middle safety valve', coachingCue: 'Stay deep' },
      { id: 'R5', label: 'R5', name: 'Right Contain', role: 'Contain', x: 880, y: 520, responsibility: 'Outside contain', coachingCue: 'Squeeze sideline' },
    ],
    rulesAndDrills: [{ title: 'Lane Spacing Rule', rule: 'Never cross over your lane neighbor until 20 yards downfield.' }],
  },
  kick_return: {
    id: 'kick_return', name: 'Kick Return Unit (Wheel KOR)', shortName: 'Kick Return', targetTempo: 'Score on Return',
    overview: 'Wheel Kickoff Return blocking scheme.', coachingMotto: 'Set the wall and seal the crease.',
    schemeOptions: [{ id: 'wheel_right', label: 'Wheel Right' }],
    players: [], rulesAndDrills: [{ title: 'Wall Rule', rule: 'Block man inside-out.' }],
  },
  punt_coverage: {
    id: 'punt_coverage', name: 'Punt Coverage Unit', shortName: 'Punt Coverage', targetTempo: 'Sub-2.0s Getoff',
    overview: 'Punt protection with gunners releasing wide.', coachingMotto: 'Protect then release.',
    schemeOptions: [{ id: 'base_punt', label: 'Base Punt' }],
    players: [], rulesAndDrills: [{ title: 'Snap Protection', rule: 'Step inside first.' }],
  },
  punt_return: {
    id: 'punt_return', name: 'Punt Return / Block Unit', shortName: 'Punt Return', targetTempo: 'Block / Return',
    overview: 'Pressure interior rush or set up sideline return.', coachingMotto: 'Eyes on the ball.',
    schemeOptions: [{ id: 'rush', label: 'Block Pressure' }],
    players: [], rulesAndDrills: [{ title: 'Fair Catch Rule', rule: 'Signal high above helmet.' }],
  },
  fg_pat: {
    id: 'fg_pat', name: 'Field Goal / PAT Unit', shortName: 'FG / PAT', targetTempo: '1.25s Kick Operation',
    overview: 'Gap protection with kick through uprights.', coachingMotto: 'Lock inside leg.',
    schemeOptions: [{ id: 'pat', label: 'Base PAT' }],
    players: [], rulesAndDrills: [{ title: 'Toe to Heel', rule: 'Interlock inside feet.' }],
  },
  fg_block: {
    id: 'fg_block', name: 'FG Block / Prevent Unit', shortName: 'FG Block', targetTempo: 'Full Penetration',
    overview: 'Interior push and edge rush.', coachingMotto: 'Drive through A-gap.',
    schemeOptions: [{ id: 'edge_rush', label: 'Edge Rush' }],
    players: [], rulesAndDrills: [{ title: 'A-Gap Surge', rule: 'Fire low into center.' }],
  },
};
