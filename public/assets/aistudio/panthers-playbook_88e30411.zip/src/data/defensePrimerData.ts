export type DefenseFormation = 'base' | 'shield' | 'vanguard' | 'shell';
export type CoverageScheme = 'blue' | 'green' | 'black';
export type SelectableFront = 'slant' | 'pinch' | 'out';
export type LineSlant = 'base_gap' | 'slant' | 'pinch' | 'angle_out' | 'out' | 'bull_rush';
export type StrengthCall = 'rip' | 'liz';
export type OffensiveFormationId = 'pro_i' | 'spread_2x2' | 'trips_3x1' | 'heavy_2te' | 'pistol_veer' | 'empty_5w';
export type BallHashPosition = 'middle' | 'left_hash' | 'right_hash';

export interface FormationCoord {
  x: number;
  y: number;
  depthYards: number;
  alignmentDesc: string;
  technique: string;
  gap: string;
}

export interface DefPlayerPosition {
  id: string;
  name: string;
  role: string;
  number?: string;
  isOutsideBacker?: boolean;
  isMiddleBacker?: boolean;
  isDefensiveLine?: boolean;
  isSecondary?: boolean;
  canBlitz?: boolean;
  sequentialTechBase: string;
  sequentialTechCode: string;
  formations: Record<DefenseFormation, FormationCoord>;
  baseAssignment: string;
  shieldAssignment: string;
  vanguardAssignment: string;
  shellAssignment: string;
  individualPressure?: {
    callName: string;
    targetGap: string;
    description: string;
    arrowEnd: { x: number; y: number };
  };
}

export const FORMATION_INFO: Record<DefenseFormation, any> = {
  base: { id: 'base', name: 'Base 3-4 Alignment', codeName: 'BASE', handSignal: 'Fist held up, palm out', summary: 'Standard 3-4 alignment with 3 down linemen and 4 linebackers.', doctrine: 'Two-high safety disguise.' },
  shield: { id: 'shield', name: 'Shield (5-2 Walked-Up)', codeName: 'SHIELD', handSignal: 'Fist held in front of body, palm in', summary: 'OLBs walk up to LOS in 5-2.', doctrine: 'Transforms into 5-man line.' },
  vanguard: { id: 'vanguard', name: 'Vanguard (Goal Line)', codeName: 'VANGUARD', handSignal: 'Crossed arms / chopping motion', summary: 'MLBs walked up to 2 yds, Safeties to 5 yds.', doctrine: 'Goal line penetration.' },
  shell: { id: 'shell', name: 'Shell (Prevent)', codeName: 'SHELL', handSignal: 'Both hands pressed back', summary: 'Deep prevent: OLBs @ 4, MLBs @ 6, Safeties @ 12+ yds.', doctrine: 'Linemen: Go get us a sack!' },
};

export const DEFENSE_PLAYERS: DefPlayerPosition[] = [
  {
    id: 'NT', name: 'Nose Tackle', role: '0-Tech Anchor', sequentialTechBase: '0 Tech Strong A gap', sequentialTechCode: '0 Tech', isDefensiveLine: true, canBlitz: false,
    formations: {
      base: { x: 500, y: 374, depthYards: 0, alignmentDesc: '0 Tech Strong A', technique: '0-Tech', gap: 'Strong A' },
      shield: { x: 500, y: 374, depthYards: 0, alignmentDesc: '0/1 Tech Shade', technique: '0/1-Tech', gap: 'Strong A' },
      vanguard: { x: 500, y: 374, depthYards: 0, alignmentDesc: '0 Tech Submarine', technique: '0-Tech', gap: 'A-Gap' },
      shell: { x: 500, y: 374, depthYards: 0, alignmentDesc: 'Bull Rush', technique: 'Bull Rush', gap: 'Sack QB' },
    },
    baseAssignment: '0 Tech with Strong A gap.', shieldAssignment: 'Anchor vs double team.', vanguardAssignment: 'Submarine low.', shellAssignment: 'Go get a sack!',
  },
  {
    id: 'LDE', name: 'Left Defensive End', role: 'Weak 4-Tech', sequentialTechBase: '4 Tech B Gap', sequentialTechCode: '4 Tech', isDefensiveLine: true, canBlitz: false,
    formations: {
      base: { x: 415, y: 374, depthYards: 0, alignmentDesc: '4 Tech B Gap', technique: '4-Tech', gap: 'Weak B' },
      shield: { x: 415, y: 374, depthYards: 0, alignmentDesc: '4/5 Tech Squeeze', technique: '4-Tech', gap: 'Weak B' },
      vanguard: { x: 415, y: 374, depthYards: 0, alignmentDesc: '4 Tech Tight', technique: '4-Tech', gap: 'B-Gap' },
      shell: { x: 415, y: 374, depthYards: 0, alignmentDesc: 'Speed Edge Rush', technique: 'Speed Rush', gap: 'Sack QB' },
    },
    baseAssignment: '4 Tech inside shade of OT.', shieldAssignment: 'Spill to Rover.', vanguardAssignment: 'Pinch B gap.', shellAssignment: 'Speed rush QB.',
  },
  {
    id: 'RDE', name: 'Right Defensive End', role: 'Strong 6-Tech', sequentialTechBase: '6 Tech Strong C Gap', sequentialTechCode: '6 Tech', isDefensiveLine: true, canBlitz: false,
    formations: {
      base: { x: 585, y: 374, depthYards: 0, alignmentDesc: '6 Tech Strong C Gap', technique: '6-Tech', gap: 'Strong C' },
      shield: { x: 585, y: 374, depthYards: 0, alignmentDesc: '6 Tech Squeeze', technique: '6-Tech', gap: 'Strong C' },
      vanguard: { x: 585, y: 374, depthYards: 0, alignmentDesc: '6 Tech Tight', technique: '6-Tech', gap: 'C-Gap' },
      shell: { x: 585, y: 374, depthYards: 0, alignmentDesc: 'Speed Edge Rush', technique: 'Speed Rush', gap: 'Sack QB' },
    },
    baseAssignment: '6 Tech outside shade of OT.', shieldAssignment: 'Spill to Sam.', vanguardAssignment: 'Squeeze dive.', shellAssignment: 'Speed rush QB.',
  },
  {
    id: 'ROV', name: 'Rover', role: 'Weak OLB', sequentialTechBase: '2x2 Outside Contain', sequentialTechCode: '2x2 Contain', isOutsideBacker: true, canBlitz: true,
    formations: {
      base: { x: 340, y: 310, depthYards: 2, alignmentDesc: '2x2 Outside Contain', technique: '2x2 Contain', gap: 'Weak D' },
      shield: { x: 330, y: 374, depthYards: 0, alignmentDesc: '2x0 on LOS', technique: '2x0 Edge', gap: 'Weak D' },
      vanguard: { x: 330, y: 374, depthYards: 0, alignmentDesc: '2x0 Edge Crash', technique: '2x0 Crash', gap: 'Edge' },
      shell: { x: 320, y: 310, depthYards: 4, alignmentDesc: '4 Yds Off Flat Buzz', technique: 'Flat Buzz', gap: 'Weak Flat' },
    },
    baseAssignment: 'Outside contain.', shieldAssignment: '2x0 on LOS outside contain.', vanguardAssignment: 'Crash edge.', shellAssignment: 'Buzz flat.',
    individualPressure: { callName: 'Rover', targetGap: 'Weak Edge', description: 'Shoots weak edge', arrowEnd: { x: 330, y: 440 } },
  },
  {
    id: 'SAM', name: 'Sam', role: 'Strong OLB', sequentialTechBase: '2x2 Outside Contain', sequentialTechCode: '2x2 Contain', isOutsideBacker: true, canBlitz: true,
    formations: {
      base: { x: 660, y: 310, depthYards: 2, alignmentDesc: '2x2 Outside Contain', technique: '2x2 Contain', gap: 'Strong D' },
      shield: { x: 710, y: 374, depthYards: 0, alignmentDesc: '2x0 on LOS', technique: '2x0 Edge', gap: 'Strong D' },
      vanguard: { x: 710, y: 374, depthYards: 0, alignmentDesc: '2x0 Edge Jam', technique: '2x0 Jam', gap: 'Edge' },
      shell: { x: 670, y: 310, depthYards: 4, alignmentDesc: '4 Yds Off Flat Buzz', technique: 'Flat Buzz', gap: 'Strong Flat' },
    },
    baseAssignment: 'Outside contain on strong side.', shieldAssignment: '2x0 on LOS jam TE.', vanguardAssignment: 'Crush TE block.', shellAssignment: 'Buzz flat.',
    individualPressure: { callName: 'Sam', targetGap: 'Strong Edge', description: 'Shoots strong edge', arrowEnd: { x: 700, y: 440 } },
  },
  {
    id: 'MIKE', name: 'Mike', role: 'Strong ILB 34-Tech', sequentialTechBase: '34 Tech Strong B Gap', sequentialTechCode: '34 Tech', isMiddleBacker: true, canBlitz: true,
    formations: {
      base: { x: 545, y: 295, depthYards: 4, alignmentDesc: '34 Tech Strong B Gap', technique: '34-Tech', gap: 'Strong B' },
      shield: { x: 545, y: 295, depthYards: 4.5, alignmentDesc: 'Stacked 4.5 yds', technique: 'Stack', gap: 'Downhill A/B' },
      vanguard: { x: 545, y: 345, depthYards: 2, alignmentDesc: '2 yds depth open gap', technique: '2-Yd Attack', gap: 'Open Gap' },
      shell: { x: 545, y: 260, depthYards: 6, alignmentDesc: '6 yds depth pass drop', technique: 'Pass Drop', gap: 'Middle Hole' },
    },
    baseAssignment: '34 Tech Strong B gap.', shieldAssignment: 'Fast scrape downhill.', vanguardAssignment: 'Open gap rule at 2 yds.', shellAssignment: 'Drop 6 yds.',
    individualPressure: { callName: 'Mike', targetGap: 'Assigned Gap', description: 'Shoots assigned gap', arrowEnd: { x: 535, y: 440 } },
  },
  {
    id: 'WILL', name: 'Will', role: 'Weak ILB 14-Tech', sequentialTechBase: '14 Tech Weak A Gap', sequentialTechCode: '14 Tech', isMiddleBacker: true, canBlitz: true,
    formations: {
      base: { x: 455, y: 295, depthYards: 4, alignmentDesc: '14 Tech Weak A Gap', technique: '14-Tech', gap: 'Weak A' },
      shield: { x: 455, y: 295, depthYards: 4.5, alignmentDesc: 'Stacked 4.5 yds', technique: 'Stack', gap: 'Cutback' },
      vanguard: { x: 455, y: 345, depthYards: 2, alignmentDesc: '2 yds depth open gap', technique: '2-Yd Attack', gap: 'Open Gap' },
      shell: { x: 455, y: 260, depthYards: 6, alignmentDesc: '6 yds depth pass drop', technique: 'Pass Drop', gap: 'Weak Hook' },
    },
    baseAssignment: '14 Tech Weak A gap.', shieldAssignment: 'Scrape cutback.', vanguardAssignment: 'Open gap rule at 2 yds.', shellAssignment: 'Drop 6 yds.',
    individualPressure: { callName: 'Will', targetGap: 'Assigned Gap', description: 'Shoots assigned gap', arrowEnd: { x: 465, y: 440 } },
  },
  {
    id: 'LCB', name: 'Left Cornerback', role: 'Boundary Corner', sequentialTechBase: 'Outside Leverage', sequentialTechCode: 'CB Off', isSecondary: true, canBlitz: false,
    formations: {
      base: { x: 152, y: 300, depthYards: 7, alignmentDesc: '7 yds off outside leverage', technique: 'Outside Lev', gap: 'Deep 1/3' },
      shield: { x: 152, y: 300, depthYards: 7, alignmentDesc: '7 yds off', technique: 'Outside Lev', gap: 'Deep 1/3' },
      vanguard: { x: 160, y: 360, depthYards: 1.5, alignmentDesc: 'Press-man', technique: 'Press-Man', gap: 'Boundary' },
      shell: { x: 140, y: 285, depthYards: 9, alignmentDesc: 'Deep cushion', technique: 'Deep Bail', gap: 'Deep 1/3' },
    },
    baseAssignment: 'Outside leverage.', shieldAssignment: 'Support run once cleared.', vanguardAssignment: 'Press-man.', shellAssignment: 'Deep bail.',
  },
  {
    id: 'RCB', name: 'Right Cornerback', role: 'Field Corner', sequentialTechBase: 'Outside Leverage', sequentialTechCode: 'CB Off', isSecondary: true, canBlitz: false,
    formations: {
      base: { x: 848, y: 300, depthYards: 7, alignmentDesc: '7 yds off outside leverage', technique: 'Outside Lev', gap: 'Deep 1/3' },
      shield: { x: 848, y: 300, depthYards: 7, alignmentDesc: '7 yds off', technique: 'Outside Lev', gap: 'Deep 1/3' },
      vanguard: { x: 840, y: 360, depthYards: 1.5, alignmentDesc: 'Press-man', technique: 'Press-Man', gap: 'Field' },
      shell: { x: 860, y: 285, depthYards: 9, alignmentDesc: 'Deep cushion', technique: 'Deep Bail', gap: 'Deep 1/3' },
    },
    baseAssignment: 'Outside leverage.', shieldAssignment: 'Support run once cleared.', vanguardAssignment: 'Press-man.', shellAssignment: 'Deep bail.',
  },
  {
    id: 'FS', name: 'Free Safety', role: 'Free Safety (Centerfield)', sequentialTechBase: 'Single-High Post', sequentialTechCode: 'FS Deep', isSecondary: true, canBlitz: false,
    formations: {
      base: { x: 430, y: 170, depthYards: 12, alignmentDesc: '12-14 yds single high', technique: 'Centerfield', gap: 'Deep Middle' },
      shield: { x: 430, y: 170, depthYards: 12, alignmentDesc: '12-14 yds deep cap', technique: 'Deep Cap', gap: 'Deep Middle' },
      vanguard: { x: 450, y: 290, depthYards: 5, alignmentDesc: '5 yds depth alley fill', technique: '5-Yd Robber', gap: 'Alley Fill' },
      shell: { x: 420, y: 140, depthYards: 14, alignmentDesc: '14 yds prevent', technique: 'Prevent', gap: 'Deep Middle' },
    },
    baseAssignment: 'Single high centerfield.', shieldAssignment: 'Cap vertical seams.', vanguardAssignment: 'Walked up to 5 yds fill.', shellAssignment: 'Deep prevent.',
  },
  {
    id: 'SS', name: 'Strong Safety', role: 'Strong Safety (Alley)', sequentialTechBase: 'Invert Apex', sequentialTechCode: 'SS Invert', isSecondary: true, canBlitz: false,
    formations: {
      base: { x: 590, y: 210, depthYards: 10, alignmentDesc: '8-10 yds deep', technique: 'Invert Apex', gap: 'Strong Box/Half' },
      shield: { x: 590, y: 210, depthYards: 10, alignmentDesc: '8-10 yds alley fill', technique: 'Alley Enforcer', gap: 'Alley Fill' },
      vanguard: { x: 580, y: 290, depthYards: 5, alignmentDesc: '5 yds depth alley stuffer', technique: '5-Yd Box', gap: 'Alley Stuffer' },
      shell: { x: 620, y: 140, depthYards: 14, alignmentDesc: '14 yds deep half', technique: 'Prevent', gap: 'Deep Half' },
    },
    baseAssignment: 'Roll down in Green, deep half in Blue.', shieldAssignment: 'Alley fill outside Sam.', vanguardAssignment: 'Walked up 5 yds destroy power.', shellAssignment: 'Deep prevent.',
  },
];
