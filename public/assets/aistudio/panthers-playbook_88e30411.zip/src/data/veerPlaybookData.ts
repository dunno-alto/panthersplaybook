export type TargetSide = 'left' | 'right';
export type DefensiveFrontId = '5-3' | '4-4' | '6-2' | '5-2' | '3-4';
export type DiveKeyBehavior = 'squeeze' | 'upfield' | 'pitch_charge';
export type PitchKeyBehavior = 'commit_qb' | 'slow_play' | 'pitch_force';
export type OffensiveConcept = 'inside_veer' | 'outside_veer' | 'trap' | 'counter' | 'flood' | 'power';
export type ZAlignmentSide = 'left' | 'right';
export type ZAlignmentType = 'wide' | 'wing';
export type EleventhPlayerMode = 'wide_z' | 'wing_z';
export type XPlayerMode = 'tight_x' | 'split_x';
export type PowerPassReceiverOption = 'whip' | 'corner' | 'arrow' | 'post' | 'checkdown';

export interface Point {
  x: number;
  y: number;
}

export interface CoachingPhase {
  phase: number;
  title: string;
  timeRange: [number, number];
  description: string;
}

export interface PositionRule {
  label: string;
  fullName: string;
  split: string;
  stance: string;
  aimingPoint: string;
  footwork: string;
  assignmentsByFront: Record<string, string>;
  coachingCue: string;
}

export interface PlayDefinition {
  id: string;
  code: string;
  name: string;
  playType: string;
  concept: OffensiveConcept;
  targetSide: TargetSide;
  primaryReadLabel: string;
  secondaryReadLabel: string;
  qbDecisionMatrix: {
    crashPull: string;
    squeezeGive: string;
    pitchPhase: string;
  };
  coachingPhases: CoachingPhase[];
  positionRules: Record<string, PositionRule>;
  getOffensivePaths: (...args: any[]) => any;
}

export interface DefensivePlayerDef {
  id: string;
  label: string;
  x: number;
  y: number;
  role: string;
}

export interface DefensiveFrontDef {
  id: DefensiveFrontId;
  name: string;
  shortLabel: string;
  players: DefensivePlayerDef[];
}

export const DEFENSIVE_FRONTS: Record<DefensiveFrontId, DefensiveFrontDef> = {
  '5-3': {
    id: '5-3',
    name: '5-3 Bear / Stack Front',
    shortLabel: '5-3 Bear',
    players: [
      { id: 'NG', label: 'NG', x: 500, y: 382, role: 'Nose Guard (0-Tech)' },
      { id: 'DT_L', label: 'DT', x: 430, y: 382, role: 'Weak DT (3-Tech)' },
      { id: 'DT_R', label: 'DT', x: 570, y: 382, role: 'Strong DT (3-Tech)' },
      { id: 'DE_L', label: 'DE', x: 340, y: 382, role: 'Weak Defensive End' },
      { id: 'DE_R', label: 'DE', x: 660, y: 382, role: 'Playside Defensive End (Read #1)' },
      { id: 'MLB', label: 'MLB', x: 500, y: 315, role: 'Middle Linebacker' },
      { id: 'WLB', label: 'WLB', x: 410, y: 315, role: 'Weakside Inside Linebacker' },
      { id: 'SLB', label: 'SLB', x: 590, y: 315, role: 'Strongside Inside Linebacker' },
      { id: 'FS', label: 'FS', x: 500, y: 160, role: 'Free Safety (TDA)' },
      { id: 'LCB', label: 'CB', x: 170, y: 320, role: 'Boundary Corner' },
      { id: 'RCB', label: 'CB', x: 830, y: 320, role: 'Field Corner' },
    ],
  },
  '4-4': {
    id: '4-4',
    name: '4-4 Split Box',
    shortLabel: '4-4 Split',
    players: [
      { id: 'DT_L', label: 'DT', x: 450, y: 382, role: 'Weak DT' },
      { id: 'DT_R', label: 'DT', x: 550, y: 382, role: 'Strong DT' },
      { id: 'DE_L', label: 'DE', x: 360, y: 382, role: 'Weak End' },
      { id: 'DE_R', label: 'DE', x: 640, y: 382, role: 'Strong End (Read #1)' },
      { id: 'ILB_L', label: 'ILB', x: 440, y: 315, role: 'Weak Inside LB' },
      { id: 'ILB_R', label: 'ILB', x: 560, y: 315, role: 'Strong Inside LB' },
      { id: 'OLB_L', label: 'OLB', x: 310, y: 330, role: 'Weak Overhang' },
      { id: 'OLB_R', label: 'OLB', x: 690, y: 330, role: 'Overhang / Pitch Key (Read #2)' },
      { id: 'FS', label: 'FS', x: 500, y: 150, role: 'Free Safety (TDA)' },
      { id: 'LCB', label: 'CB', x: 170, y: 320, role: 'Corner' },
      { id: 'RCB', label: 'CB', x: 830, y: 320, role: 'Corner' },
    ],
  },
  '6-2': {
    id: '6-2',
    name: '6-2 Wide Tackle',
    shortLabel: '6-2 Wide',
    players: [
      { id: 'G_L', label: 'DG', x: 460, y: 382, role: 'Guard' },
      { id: 'G_R', label: 'DG', x: 540, y: 382, role: 'Guard' },
      { id: 'T_L', label: 'DT', x: 400, y: 382, role: 'Weak DT' },
      { id: 'T_R', label: 'DT', x: 600, y: 382, role: 'Strong DT' },
      { id: 'E_L', label: 'DE', x: 330, y: 382, role: 'Weak End' },
      { id: 'E_R', label: 'DE', x: 670, y: 382, role: 'Strong End (Read #1)' },
      { id: 'LB_L', label: 'LB', x: 450, y: 315, role: 'Weak ILB' },
      { id: 'LB_R', label: 'LB', x: 550, y: 315, role: 'Strong ILB' },
      { id: 'FS', label: 'FS', x: 500, y: 160, role: 'Free Safety (TDA)' },
      { id: 'LCB', label: 'CB', x: 170, y: 320, role: 'Corner' },
      { id: 'RCB', label: 'CB', x: 830, y: 320, role: 'Corner' },
    ],
  },
  '5-2': {
    id: '5-2',
    name: '5-2 Okie Front',
    shortLabel: '5-2 Okie',
    players: [
      { id: 'NG', label: 'NG', x: 500, y: 382, role: 'Nose Guard' },
      { id: 'DT_L', label: 'DT', x: 420, y: 382, role: 'Weak Tackle' },
      { id: 'DT_R', label: 'DT', x: 580, y: 382, role: 'Strong Tackle' },
      { id: 'DE_L', label: 'DE', x: 330, y: 382, role: 'Weak End' },
      { id: 'DE_R', label: 'DE', x: 670, y: 382, role: 'Strong End (Read #1)' },
      { id: 'ILB_L', label: 'ILB', x: 450, y: 310, role: 'Weak ILB' },
      { id: 'ILB_R', label: 'ILB', x: 550, y: 310, role: 'Strong ILB' },
      { id: 'FS', label: 'FS', x: 450, y: 160, role: 'Free Safety (TDA)' },
      { id: 'SS', label: 'SS', x: 550, y: 180, role: 'Strong Safety' },
      { id: 'LCB', label: 'CB', x: 170, y: 320, role: 'Corner' },
      { id: 'RCB', label: 'CB', x: 830, y: 320, role: 'Corner' },
    ],
  },
  '3-4': {
    id: '3-4',
    name: '3-4 Two-High Defense',
    shortLabel: '3-4 Base',
    players: [
      { id: 'NT', label: 'NT', x: 500, y: 382, role: 'Nose 0-Tech' },
      { id: 'DE_L', label: 'DE', x: 415, y: 382, role: 'Weak 4-Tech' },
      { id: 'DE_R', label: 'DE', x: 585, y: 382, role: 'Strong 6-Tech (Read #1)' },
      { id: 'ROV', label: 'ROV', x: 330, y: 340, role: 'Weak OLB' },
      { id: 'SAM', label: 'SAM', x: 680, y: 340, role: 'Strong OLB (Read #2)' },
      { id: 'WILL', label: 'WILL', x: 455, y: 300, role: 'Weak ILB' },
      { id: 'MIKE', label: 'MIKE', x: 545, y: 300, role: 'Strong ILB' },
      { id: 'FS', label: 'FS', x: 430, y: 160, role: 'Free Safety (TDA)' },
      { id: 'SS', label: 'SS', x: 590, y: 190, role: 'Strong Safety' },
      { id: 'LCB', label: 'CB', x: 170, y: 320, role: 'Boundary Corner' },
      { id: 'RCB', label: 'CB', x: 830, y: 320, role: 'Field Corner' },
    ],
  },
};

export const VEER_PLAYBOOK: Record<string, PlayDefinition> = {
  '22-inside-veer': {
    id: '22-inside-veer',
    code: '22 Veer / 31 Veer',
    name: '22/31 Veer (Inside Veer)',
    playType: 'Option / Inside Run',
    concept: 'inside_veer',
    targetSide: 'right',
    primaryReadLabel: '#1 Dive Key (Playside Defensive End)',
    secondaryReadLabel: '#2 Pitch Key (SS OLB / Overhang Defender)',
    qbDecisionMatrix: {
      crashPull:
        '#1 PS DE crashes: Ride Dive Back to ~45 degree angle, pull the ball, and attack past the LOS downhill at SS OLB/Overhang.',
      squeezeGive:
        '#1 PS DE widens, stays square, or rushes upfield: Give cleanly to Dive Back hitting the inside guard seam track with continuous momentum.',
      pitchPhase:
        'Attack secondary read (SS OLB/Overhang). Only pitch if SS OLB steps toward QB and fully commits. Absorb initial tackle attempt, turn toward pitch back, and pitch slightly ahead of him.',
    },
    coachingPhases: [
      {
        phase: 1,
        title: 'Phase 1: Pre-Snap Alignment & Stance',
        timeRange: [0, 0.2],
        description: 'OL 2-3 ft splits. QB under center low with even feet. Dive Back 3-4 yds behind PS Guard, Pitch Back 3-4 yds behind BS Guard (Backs must be even). WRs align to numbers.',
      },
      {
        phase: 2,
        title: 'Phase 2: Mesh & #1 DE Read',
        timeRange: [0.21, 0.5],
        description: 'QB takes 1-ft step play side, WS foot meets PS foot. Extends ball into mesh area, eyes locked on PS End. Dive Back creates high inside elbow pocket.',
      },
      {
        phase: 3,
        title: 'Phase 3: Keep Attack & Pitch Key Read',
        timeRange: [0.51, 0.75],
        description: 'On Pull, QB turns 45 degrees, crosses LOS, attacks SS OLB. Pitch back opens parallel maintaining 3-4x1 pitch ratio with eyes on QB.',
      },
      {
        phase: 4,
        title: 'Phase 4: Pitch / Keep Finish',
        timeRange: [0.76, 1.0],
        description: 'If SS OLB commits to QB: Pitch slightly ahead of Pitch Back. Pitch Back catches, plants outside foot, cuts vertically North/South.',
      },
    ],
    positionRules: {
      QB: {
        label: 'QB',
        fullName: 'Quarterback (Read & Pitch Distributor)',
        split: 'Under Center',
        stance: 'Under center low with even feet.',
        aimingPoint: 'Playside DE (#1 Key) -> SS OLB (#2 Overhang)',
        footwork:
          'Step to play side with play side foot approx 1 ft. Second step is with weakside foot meeting playside foot to create an even stance. Extend ball into mesh area, ride dive back through hole with eyes on PS End.',
        assignmentsByFront: {
          '5-3': 'Read 5-3 Playside DE. If crashes inside, ride dive back to 45 deg, pull, attack SS OLB/overhang. Pitch only on full commitment.',
          '4-4': 'Read 4-4 Playside DE. If crashes, pull and attack OLB pitch key. Absorb initial tackle contact, pitch slightly ahead of Pitch Back.',
          '6-2': 'Read DE. Give if he sits. If crashes, pull downhill past LOS attacking safety/overhang.',
          '5-2': 'Read 5-2 End. Pull on crash, attack outside backer.',
          '3-4': 'Read 6-tech Strong DE. If he crashes, pull and attack Sam LB (Read #2). Deliver pitch leading the Pitch Back.',
        },
        coachingCue: 'Low even feet, ride to 45 deg, eyes on PS End, absorb tackle to pitch!',
      },
      RH: {
        label: 'RH',
        fullName: 'Playside Dive Back (Primary Inside Carrier)',
        split: 'Directly behind Playside Guard at 3-4 yards depth',
        stance: 'Butt down, back at 45 degree angle, chest up, hand lightly in the ground.',
        aimingPoint: 'Step 1: Outside leg of PS Guard. Step 2: Split PS Guard.',
        footwork:
          'Upon snap, take outside foot aiming directly at outside leg of PS Guard. Second step splits PS Guard. Immediate wide pocket with inside elbow up high.',
        assignmentsByFront: {
          '5-3': 'Charge inside seam track. Clamp down only when QB arms clear the mesh. ALWAYS clamp whether receiving ball or faking, baiting defender.',
          '4-4': 'Explode downhill between Center and PSG. Clamp pocket on give/fake. Continue hard as decoy if QB pulls.',
          '6-2': 'Fast vertical track splitting PSG. Attack inside gap with shoulder pad leverage.',
          '5-2': 'Hit inside B-gap track violently off PSG block. Clamp hard to secure illusion.',
          '3-4': 'Aim at PSG outside leg, second step splits guard. Form high elbow pocket and explode through line.',
        },
        coachingCue: 'Inside elbow high, split the guard, ALWAYS clamp down 100%!',
      },
      LH: {
        label: 'LH',
        fullName: 'Backside Pitch Back (Trailing Perimeter Option)',
        split: 'Directly behind Backside Guard at 3-4 yards depth (EVEN with Dive Back)',
        stance: 'Butt down, back at 45 degree angle, chest up, hand lightly in the ground. Backs must be even!',
        aimingPoint: '3-4 x 1 pitch relationship on QB hip',
        footwork:
          'Upon snap, open parallel to the line with eyes always on the QB. Match QB pace maintaining 3-4x1 pitch ratio. Push upfield post-mesh as QB crosses LOS.',
        assignmentsByFront: {
          '5-3': 'Maintain 3-4x1 ratio. On pitch: plant outside foot, cut directly upfield North/South. Avoid drifting to sideline.',
          '4-4': 'Keep eyes on QB. On pitch: plant on outside foot, cut vertically for positive yardage.',
          '6-2': 'Trail QB with strict 3-4x1 spacing. Plant outside foot on pitch and accelerate North/South.',
          '5-2': 'Sprint parallel to LOS matching QB pace. Catch pitch, plant outside foot, burst upfield.',
          '3-4': 'Open parallel, eyes locked on QB. Catch pitch cleanly, plant outside foot, vertical North/South cut.',
        },
        coachingCue: 'Backs must be even! 3-4x1 ratio, plant outside foot, cut North/South!',
      },
      C: {
        label: 'C',
        fullName: 'Center (Interior Double-Team Anchor)',
        split: '0 ft (Ball Snap)',
        stance: 'Balanced 3-point stance, heads-up snap.',
        aimingPoint: 'Weakside Tackle (DT) -> Weakside ILB',
        footwork: 'Fire playside/backside with Guard to secure DT first before climbing.',
        assignmentsByFront: {
          '5-3': 'Double team WS Tackle with BSG up to WS ILB. Must secure DT first before climbing to linebacker.',
          '4-4': 'Combo DT with Backside Guard up to inside linebacker. DT must be neutralized first.',
          '6-2': 'Block interior defensive guard/tackle with BS Guard. Secure line of scrimmage first.',
          '5-2': 'Combo Nose/Tackle with BSG to weak inside backer. Secure DT first.',
          '3-4': 'Combo 0-tech Nose with BSG to Weak Inside LB (Will). Lock DT first.',
        },
        coachingCue: 'Double team WS Tackle with BSG! Must secure DT first!',
      },
      LG: {
        label: 'LG / BSG',
        fullName: 'Backside Guard (BSG)',
        split: '2-3 ft split',
        stance: '3-point stance, weight balanced.',
        aimingPoint: 'Weakside Tackle (DT) -> Weakside ILB',
        footwork: 'Drive step with Center into WS Tackle.',
        assignmentsByFront: {
          '5-3': 'BSG + C double-team WS Tackle to WS ILB. Must secure DT first before releasing to linebacker.',
          '4-4': 'Double team interior DT with Center, climb to weak ILB once DT is secured.',
          '6-2': 'Drive block WS interior defensive tackle with Center.',
          '5-2': 'Double team WS Tackle to weak linebacker. Secure DT first.',
          '3-4': 'Double team interior tackle with Center, peel to Will LB.',
        },
        coachingCue: 'BSG + C double team WS Tackle! Secure DT first!',
      },
      RG: {
        label: 'RG / PSG',
        fullName: 'Playside Guard (PSG)',
        split: '2-3 ft split',
        stance: '3-point stance, inside hand down.',
        aimingPoint: 'Playside Tackle (DT) -> Strongside ILB',
        footwork: 'Power drive step into PS Tackle with PST.',
        assignmentsByFront: {
          '5-3': 'PSG + PST double-team PS Tackle to SS ILB. Must secure DT first before releasing to linebacker.',
          '4-4': 'Double team playside DT with PST up to strong inside linebacker. Secure DT first.',
          '6-2': 'Drive block PS interior tackle with PST up to Mike/SS ILB.',
          '5-2': 'Combo PS Tackle with PST up to strong ILB.',
          '3-4': 'Double team 4/5-tech tackle with PST up to Mike LB. Must secure DT first.',
        },
        coachingCue: 'PSG + PST double team PS Tackle! Must secure DT first!',
      },
      RT: {
        label: 'RT / PST',
        fullName: 'Playside Tackle (PST)',
        split: '2-3 ft split',
        stance: '3-point stance, weight forward.',
        aimingPoint: 'Playside Tackle (DT) -> SS ILB',
        footwork: 'Drive step into PS Tackle, assist Y on SS ILB.',
        assignmentsByFront: {
          '5-3': 'PSG + PST double-team PS Tackle to SS ILB. Secure DT first, then assist Y on SS ILB.',
          '4-4': 'Combo PS DT with PSG. Climb to assist on SS ILB so Y can release.',
          '6-2': 'Drive block PS DT with PSG. Secure line then climb.',
          '5-2': 'Double team PS Tackle with PSG, climb to SS ILB.',
          '3-4': 'Double team strong tackle with PSG, then assist on SS ILB (Mike).',
        },
        coachingCue: 'PST + PSG combo DT! Secure DT then assist Y on SS ILB!',
      },
      LT: {
        label: 'LT / BST',
        fullName: 'Backside Tackle (BST)',
        split: '2-3 ft split',
        stance: '3-point stance, balanced.',
        aimingPoint: 'Backside Defensive End -> TDA (Free Safety)',
        footwork: 'Strike BS End, hold for 2 seconds, release to TDA/FS.',
        assignmentsByFront: {
          '5-3': 'Blocks BS End for 2 seconds, then heads to Touchdown Area (TDA) / Free Safety.',
          '4-4': 'Block BS End for 2 seconds, then release directly to Free Safety (TDA).',
          '6-2': 'Hold BS End for 2 seconds, release to deep safety.',
          '5-2': 'Block BS End for 2 count, climb to TDA/FS.',
          '3-4': 'Block BS End for 2 seconds, release to TDA to secure Free Safety.',
        },
        coachingCue: 'Block BS End for 2 SECONDS, then head to TDA (FS)!',
      },
      YTE: {
        label: 'Y',
        fullName: 'Tight End (Y)',
        split: '2-3 ft split in-line',
        stance: '3-point stance, eyes inside.',
        aimingPoint: 'SS ILB -> TDA / Free Safety',
        footwork: 'Block down on SS ILB, release to FS once PST assists.',
        assignmentsByFront: {
          '5-3': 'Blocks down to SS ILB and can release to secure FS once PST comes to assist on SS ILB.',
          '4-4': 'Block down on strong ILB. Release to secure Free Safety once PST assists on ILB.',
          '6-2': 'Down block on strong ILB, climb to safety when tackle arrives.',
          '5-2': 'Block down on SS ILB, release to Free Safety on PST arrival.',
          '3-4': 'Block down to SS ILB (Mike/Sam), release to FS once PST comes to assist.',
        },
        coachingCue: 'Block down to SS ILB! Release to secure FS once PST assists!',
      },
      W: {
        label: 'WR',
        fullName: 'Wide Receivers (Split End & Flanker)',
        split: 'Center: 3 yds inside numbers | Boundary: On numbers | Field: 5 yds inside numbers',
        stance: 'Solid stance, eyes on the ball. Do NOT receive cadence!',
        aimingPoint: 'Deep vertical stem -> Stalk block CB',
        footwork: 'Fire off ball selling deep vertical, press outside leverage to turn CB back.',
        assignmentsByFront: {
          '5-3': 'Fire off ball selling deep vertical route. Press outside leverage to turn CB back to ball. On run recognize: short choppy steps, stalk block CB without holding.',
          '4-4': 'Sell deep vertical. Turn corner s back to ball. Stalk block with short choppy steps upon run recognition. Never grab jersey.',
          '6-2': 'Sell go route, press outside leverage. Breakdown into stalk block on run recognition.',
          '5-2': 'Fire off snap, eyes on ball. Sell vertical, stalk block corner. If beaten, get in the way and lengthen tackle angle.',
          '3-4': 'Sell deep vertical route, turn corner back to ball, stalk block without holding.',
        },
        coachingCue: 'Eyes on ball (no cadence)! Sell vertical, turn CB back, short choppy stalk block!',
      },
    },
    getOffensivePaths: (frontId, diveBehavior, pitchBehavior) => {
      // Dynamic simulated paths for tactical visualizer
      return {};
    },
  },
};

export function getActivePlayDefinition(
  concept: OffensiveConcept,
  targetSide: TargetSide,
  ...rest: any[]
): PlayDefinition {
  return VEER_PLAYBOOK['22-inside-veer'];
}

export function getBaseOffensiveAlignment(...args: any[]) {
  return {};
}

export const PRACTICE_DRILLS = [
  {
    id: 'mesh_pod',
    title: 'Veer Mesh & Read Pod Drill',
    durationMin: 10,
    playersInvolved: 'QBs, Dive Backs, Pitch Backs, Read Keys',
    objective: 'Perfect the low even-foot QB stance, 45-degree dive ride, and disciplined pitch relationship.',
    setupSteps: [
      'Set QB under center with Dive Back 3-4 yards behind PSG and Pitch Back 3-4 yards behind BSG (Backs must be even).',
      'Coach positions stand-up dummy or defensive player at playside end (#1 Dive Key).',
      'Coach indicates Crash or Upfield on snap.',
      'QB rides Dive Back to 45 degrees; gives if DE sits or pulls and attacks overhang if DE crashes.',
    ],
    coachingPoints: [
      'Dive Back must provide a high inside elbow pocket and ALWAYS clamp down 100% whether he has the ball or not.',
      'Pitch Back opens parallel, maintains 3-4x1 pitch ratio, plants outside foot, and cuts North/South upon pitch.',
    ],
    levelProgression: {
      beginner: 'Walking pace mesh: QB rides dive back to 45 deg, checks DE shoulders.',
      intermediate: 'Full speed mesh with live #1 DE crashing or feathering.',
      advanced: 'Two-key read with live #1 DE and #2 SS OLB overhang.',
    },
  },
  {
    id: 'ol_combo_drill',
    title: 'OL Combo & 2-Second BST Hold Drill',
    durationMin: 12,
    playersInvolved: 'Offensive Line (C, Guards, Tackles, TE)',
    objective: 'Master 2-3 ft splits, combo blocks securing DT first, and BST 2-second hold then release to TDA/FS.',
    setupSteps: [
      'Set OL with strict 2-3 ft splits.',
      'BSG + C combo weakside tackle to WS ILB (must secure DT first).',
      'PSG + PST combo playside tackle to SS ILB (must secure DT first).',
      'BST blocks BS End for 2 seconds, then releases to TDA (FS).',
      'Y blocks down to SS ILB and releases to FS once PST arrives.',
    ],
    coachingPoints: [
      'Never leave DT unsecured before climbing to second-level linebackers.',
      'BST must count two full seconds on BS End before climbing to Free Safety.',
    ],
    levelProgression: {
      beginner: 'Board drills focusing on 2-3 ft splits and 2-second BST count.',
      intermediate: 'Live defensive tackles with scraping linebackers.',
      advanced: 'Full front 5-man line stunts with slant and pinch pressure.',
    },
  },
  {
    id: 'wr_stalk_block',
    title: 'WR No-Cadence Vertical & Stalk Drill',
    durationMin: 10,
    playersInvolved: 'Wide Receivers & Cornerbacks',
    objective: 'Train WRs to key ball snap without cadence, sell deep vertical routes to turn CB backs, and stalk block cleanly.',
    setupSteps: [
      'Align WRs: 3 yds inside numbers (middle of field), on numbers (boundary), 5 yds inside numbers (field).',
      'WRs take solid stance with eyes fixed on the football (no cadence dependency).',
      'On snap, fire vertically to press outside leverage and turn CBs back to ball.',
      'Breakdown with short choppy steps and stalk block without holding.',
    ],
    coachingPoints: [
      'Do not listen to QB cadence; watch the football snap.',
      'Sell deep route to turn the CB back; never hold or grab jersey.',
      'If beaten, stay in front to create a longer pursuit angle.',
    ],
    levelProgression: {
      beginner: 'Stance and ball-key takeoff drill with alignment verification.',
      intermediate: 'Stemming outside leverage to turn CB hips.',
      advanced: 'Full speed live stalk block against aggressive perimeter corners.',
    },
  },
];
