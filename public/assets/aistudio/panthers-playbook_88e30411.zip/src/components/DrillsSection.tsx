import React, { useState } from 'react';
import { Clock } from 'lucide-react';
import { PRACTICE_DRILLS } from '../data/veerPlaybookData';

export const DrillsSection: React.FC = () => {
  const [selectedLevel, setSelectedLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [completedDrills, setCompletedDrills] = useState<Record<string, boolean>>({});

  const toggleDrillDone = (id: string) => {
    setCompletedDrills((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const goldenRules = [
    {
      title: '01. 2-3 Foot Offensive Line Splits (Non-Negotiable)',
      detail: 'Maintain strict 2-3 foot spacing in practice so Guards and Tackles create wide A/B gap running lanes.',
    },
    {
      title: '02. Backs Aligned at 3-4 Yards Depth Behind Guards (Even Alignment)',
      detail: 'Dive Back behind PSG and Pitch Back behind BSG at 3-4 yards depth in identical 45-degree stances. Backs MUST be even!',
    },
    {
      title: '03. BST Blocks BS End for 2 Seconds Then Heads to TDA (FS)',
      detail: 'BST strikes BS End, locks him for 2 full seconds, then climbs downhill to secure the Free Safety in the Touchdown Area.',
    },
    {
      title: '04. Combo Blocks: Secure Defensive Tackle FIRST',
      detail: 'BSG + C combo WS Tackle to WS ILB, and PSG + PST combo PS Tackle to SS ILB. DT must be secured before releasing to linebackers.',
    },
  ];

  return (
    <section id="drills" className="py-8 border-t border-[#162A33] space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <p className="text-xs text-teal-400 font-mono uppercase tracking-wider font-semibold">
            Practice Progression & Drill Circuit
          </p>
          <h2 className="text-2xl font-bold text-white font-display">
            Practice Drills & Execution Checkpoints
          </h2>
        </div>
        <div className="flex items-center gap-1 p-1 bg-[#09151C] border border-[#162A33] rounded-lg">
          {(['beginner', 'intermediate', 'advanced'] as const).map((lvl) => (
            <button
              key={lvl}
              onClick={() => setSelectedLevel(lvl)}
              className={`px-3 py-1 rounded text-xs font-mono font-bold capitalize cursor-pointer transition-colors ${
                selectedLevel === lvl ? 'bg-teal-400 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              {lvl}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {PRACTICE_DRILLS.map((drill) => (
          <div key={drill.id} className="p-4 rounded-xl border border-[#162A33] bg-[#0A1318] space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                <span className="text-teal-400 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> {drill.durationMin} Mins
                </span>
                <span className="truncate">{drill.playersInvolved}</span>
              </div>
              <h3 className="text-base font-bold text-white mt-1.5 font-display">{drill.title}</h3>
              <p className="text-xs text-slate-300 mt-1">{drill.objective}</p>
              <div className="mt-3 pt-2 border-t border-[#162A33]">
                <span className="text-[10px] font-mono uppercase text-slate-400 block mb-1">Setup:</span>
                <ul className="text-xs text-slate-300 space-y-1 list-disc list-inside">
                  {drill.setupSteps.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ul>
              </div>
            </div>
            <button
              onClick={() => toggleDrillDone(drill.id)}
              className={`w-full py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                completedDrills[drill.id] ? 'bg-teal-400 text-slate-950' : 'bg-[#101F26] text-slate-200 border border-[#1D3643]'
              }`}
            >
              {completedDrills[drill.id] ? '✓ Completed' : 'Mark Complete'}
            </button>
          </div>
        ))}
      </div>

      <div className="p-5 rounded-xl border border-[#162A33] bg-[#0A1318] space-y-3">
        <h3 className="text-lg font-bold text-white font-display">
          Offensive Non-Negotiables & Execution Rules
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {goldenRules.map((r, i) => (
            <div key={i} className="p-3 rounded-lg border border-[#162A33] bg-[#070E13]">
              <div className="font-bold text-teal-300 font-mono">{r.title}</div>
              <div className="text-slate-300 mt-1 leading-relaxed font-sans">{r.detail}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
