import React from 'react';
import { PlayDefinition, DefensiveFrontId, DiveKeyBehavior, PitchKeyBehavior, Point, DEFENSIVE_FRONTS } from '../data/veerPlaybookData';

export interface CoachNotation {
  id: string;
  type: 'freehand' | 'arrow';
  points: Point[];
  color: string;
}

interface TacticalFieldCanvasProps {
  play: PlayDefinition;
  frontId: DefensiveFrontId;
  diveBehavior: DiveKeyBehavior;
  pitchBehavior: PitchKeyBehavior;
  eleventhMode: any;
  xMode: any;
  zSide: any;
  targetSide: 'left' | 'right';
  progress: number;
  fieldTheme: string;
  selectedPlayerId: string;
  onSelectPlayer: (id: string) => void;
  showGapLabels: boolean;
  showBlockingAngles: boolean;
  chalkboardMode: boolean;
  customOffsets: Record<string, Point>;
  onUpdateCustomOffset: (id: string, pt: Point) => void;
  customArrows: CoachNotation[];
  onAddCustomArrow: (arr: CoachNotation) => void;
  penMode: 'freehand' | 'arrow';
  penColor: string;
  powerPassReceiver?: any;
}

export const TacticalFieldCanvas: React.FC<TacticalFieldCanvasProps> = ({
  play,
  frontId,
  diveBehavior,
  pitchBehavior,
  targetSide,
  progress,
  selectedPlayerId,
  onSelectPlayer,
  showGapLabels,
  showBlockingAngles,
}) => {
  const activeFront = DEFENSIVE_FRONTS[frontId] || DEFENSIVE_FRONTS['5-3'];

  // Calculate animated position of QB and Backs based on progress and reads
  const isGive = diveBehavior === 'upfield';
  const isPitch = !isGive && pitchBehavior === 'commit_qb';

  // Base Offense coordinates (2-3 ft splits)
  // Center: 500, 412
  // LG: 445, 412. RG: 555, 412
  // LT: 390, 412. RT: 610, 412
  // Y: 670, 412 (on right)
  // QB: 500, 445
  // Playside Back (RH): 555, 475 (behind PSG)
  // Backside Back (LH): 445, 475 (behind BSG - Even)
  // WR Left (X): 170, 412
  // WR Right (Z): 830, 412

  const qbBaseX = 500;
  const qbBaseY = 445;
  const diveBaseX = targetSide === 'right' ? 555 : 445;
  const diveBaseY = 475;
  const pitchBaseX = targetSide === 'right' ? 445 : 555;
  const pitchBaseY = 475;

  // Animated coordinates
  let qbX = qbBaseX;
  let qbY = qbBaseY;
  let diveX = diveBaseX;
  let diveY = diveBaseY;
  let pitchX = pitchBaseX;
  let pitchY = pitchBaseY;

  if (progress <= 0.35) {
    const t = progress / 0.35;
    // QB 1-ft step play-side and meet feet
    const dir = targetSide === 'right' ? 1 : -1;
    qbX = qbBaseX + dir * 18 * t;
    qbY = qbBaseY - 10 * t;

    // Dive back step outside leg PSG then split
    diveX = diveBaseX + dir * 12 * t;
    diveY = diveBaseY - 65 * t;

    // Pitch back opens parallel
    pitchX = pitchBaseX + dir * 25 * t;
    pitchY = pitchBaseY - 5 * t;
  } else if (progress <= 0.65) {
    const t = (progress - 0.35) / 0.3;
    const dir = targetSide === 'right' ? 1 : -1;
    if (isGive) {
      // Dive back has ball, bursts through hole
      diveX = diveBaseX + dir * (12 + 15 * t);
      diveY = 410 - 80 * t;
      qbX = qbBaseX + dir * 18;
      qbY = qbBaseY - 10;
    } else {
      // QB pulls ball, turns 45 deg, attacks past LOS
      diveX = diveBaseX + dir * 20;
      diveY = 410 - 70 * t; // Runs hard as decoy
      qbX = qbBaseX + dir * (18 + 70 * t);
      qbY = 435 - 90 * t;
    }
    // Pitch back stays in 3-4x1 pitch ratio
    pitchX = pitchBaseX + dir * (25 + 75 * t);
    pitchY = pitchBaseY - 45 * t;
  } else {
    const t = (progress - 0.65) / 0.35;
    const dir = targetSide === 'right' ? 1 : -1;
    if (isGive) {
      diveX = diveBaseX + dir * 27;
      diveY = 330 - 100 * t;
      qbX = qbBaseX + dir * 18;
      qbY = 425;
      pitchX = pitchBaseX + dir * 100;
      pitchY = 430;
    } else if (isPitch) {
      // Pitch back receives pitch, plants outside foot, cuts North/South
      qbX = qbBaseX + dir * (88 + 15 * t);
      qbY = 345 - 20 * t;
      pitchX = pitchBaseX + dir * (100 + 10 * t);
      pitchY = 430 - 150 * t; // Vertical cut North/South!
      diveX = diveBaseX + dir * 20;
      diveY = 340 - 40 * t;
    } else {
      // QB Keep downhill
      qbX = qbBaseX + dir * (88 + 30 * t);
      qbY = 345 - 130 * t;
      pitchX = pitchBaseX + dir * (100 + 50 * t);
      pitchY = 430 - 60 * t;
      diveX = diveBaseX + dir * 20;
      diveY = 300;
    }
  }

  return (
    <svg viewBox="0 0 1000 620" className="w-full h-full">
      {/* Night Turf Background */}
      <rect width="1000" height="620" fill="#060D12" />
      {[0, 60, 120, 180, 240, 300, 360, 420, 480, 540, 600].map((yVal, i) => (
        <rect
          key={yVal}
          x="0"
          y={yVal}
          width="1000"
          height="60"
          fill={i % 2 === 0 ? '#060E13' : '#09161F'}
        />
      ))}
      {/* Hash Marks */}
      {[90, 150, 210, 270, 330, 390, 450, 510, 570].map((yVal) => (
        <g key={yVal} opacity="0.35">
          <line x1="330" y1={yVal - 6} x2="330" y2={yVal + 6} stroke="#94A3B8" strokeWidth="1.8" />
          <line x1="670" y1={yVal - 6} x2="670" y2={yVal + 6} stroke="#94A3B8" strokeWidth="1.8" />
        </g>
      ))}

      {/* Line of Scrimmage */}
      <line x1="60" y1="390" x2="940" y2="390" stroke="#38BDF8" strokeWidth="2.5" />
      <text x="75" y="385" fill="#38BDF8" fontSize="11" fontFamily="monospace" fontWeight="bold">
        LINE OF SCRIMMAGE
      </text>

      {/* Blocking vectors if enabled */}
      {showBlockingAngles && (
        <g opacity="0.85">
          {/* BST blocks BS End for 2s then climbs to TDA/FS */}
          <line x1="390" y1="412" x2="360" y2="390" stroke="#FACC15" strokeWidth="2.5" strokeDasharray="4 2" />
          <line x1="360" y1="390" x2="480" y2="180" stroke="#2DD4BF" strokeWidth="2" strokeDasharray="3 3" />
          <text x="360" y="375" fill="#FACC15" fontSize="8" fontFamily="monospace">BST 2s Hold -> TDA</text>

          {/* BSG + C Dbl team WS Tackle to WS ILB */}
          <line x1="445" y1="412" x2="435" y2="388" stroke="#FACC15" strokeWidth="3" />
          <line x1="500" y1="412" x2="445" y2="388" stroke="#FACC15" strokeWidth="3" />
          <line x1="440" y1="388" x2="415" y2="325" stroke="#2DD4BF" strokeWidth="2" strokeDasharray="4 2" />
          <text x="450" y="370" fill="#FACC15" fontSize="8" fontFamily="monospace">BSG+C Dbl to ILB</text>

          {/* PSG + PST Dbl team PS Tackle to SS ILB */}
          <line x1="555" y1="412" x2="565" y2="388" stroke="#FACC15" strokeWidth="3" />
          <line x1="610" y1="412" x2="575" y2="388" stroke="#FACC15" strokeWidth="3" />
          <line x1="570" y1="388" x2="585" y2="325" stroke="#2DD4BF" strokeWidth="2" strokeDasharray="4 2" />
          <text x="580" y="370" fill="#FACC15" fontSize="8" fontFamily="monospace">PSG+PST Dbl to ILB</text>

          {/* Y blocks down on SS ILB and releases to FS */}
          <line x1="670" y1="412" x2="600" y2="330" stroke="#FACC15" strokeWidth="2.5" strokeDasharray="4 2" />
          <line x1="600" y1="330" x2="520" y2="180" stroke="#2DD4BF" strokeWidth="2" strokeDasharray="3 3" />
          <text x="640" y="350" fill="#FACC15" fontSize="8" fontFamily="monospace">Y Down -> FS</text>

          {/* WR stalk blocks */}
          <line x1="170" y1="412" x2="170" y2="330" stroke="#FACC15" strokeWidth="2" strokeDasharray="4 2" />
          <text x="180" y="340" fill="#FACC15" fontSize="8" fontFamily="monospace">Vertical -> Stalk</text>
          <line x1="830" y1="412" x2="830" y2="330" stroke="#FACC15" strokeWidth="2" strokeDasharray="4 2" />
          <text x="840" y="340" fill="#FACC15" fontSize="8" fontFamily="monospace">Vertical -> Stalk</text>
        </g>
      )}

      {/* Defensive Front Players */}
      {activeFront.players.map((d) => (
        <g key={d.id} className="cursor-pointer">
          <circle cx={d.x} cy={d.y} r="15" fill="#1E293B" stroke="#F87171" strokeWidth="2" />
          <text x={d.x} y={d.y + 4} fill="#FCA5A5" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">
            {d.label}
          </text>
        </g>
      ))}

      {/* Offensive Static Linemen */}
      {/* BST (LT) */}
      <g onClick={() => onSelectPlayer('LT')} className="cursor-pointer">
        <circle cx="390" cy="412" r="15" fill={selectedPlayerId === 'LT' ? '#0F766E' : '#0B1D28'} stroke="#2DD4BF" strokeWidth="2" />
        <text x="390" y="416" fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">BST</text>
      </g>
      {/* BSG (LG) */}
      <g onClick={() => onSelectPlayer('LG')} className="cursor-pointer">
        <circle cx="445" cy="412" r="15" fill={selectedPlayerId === 'LG' ? '#0F766E' : '#0B1D28'} stroke="#2DD4BF" strokeWidth="2" />
        <text x="445" y="416" fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">BSG</text>
      </g>
      {/* C */}
      <g onClick={() => onSelectPlayer('C')} className="cursor-pointer">
        <circle cx="500" cy="412" r="15" fill={selectedPlayerId === 'C' ? '#0F766E' : '#0B1D28'} stroke="#2DD4BF" strokeWidth="2" />
        <text x="500" y="416" fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">C</text>
      </g>
      {/* PSG (RG) */}
      <g onClick={() => onSelectPlayer('RG')} className="cursor-pointer">
        <circle cx="555" cy="412" r="15" fill={selectedPlayerId === 'RG' ? '#0F766E' : '#0B1D28'} stroke="#2DD4BF" strokeWidth="2" />
        <text x="555" y="416" fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">PSG</text>
      </g>
      {/* PST (RT) */}
      <g onClick={() => onSelectPlayer('RT')} className="cursor-pointer">
        <circle cx="610" cy="412" r="15" fill={selectedPlayerId === 'RT' ? '#0F766E' : '#0B1D28'} stroke="#2DD4BF" strokeWidth="2" />
        <text x="610" y="416" fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">PST</text>
      </g>
      {/* Y TE */}
      <g onClick={() => onSelectPlayer('YTE')} className="cursor-pointer">
        <circle cx="670" cy="412" r="15" fill={selectedPlayerId === 'YTE' ? '#0F766E' : '#0B1D28'} stroke="#2DD4BF" strokeWidth="2" />
        <text x="670" y="416" fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">Y</text>
      </g>
      {/* WRs */}
      <g onClick={() => onSelectPlayer('W')} className="cursor-pointer">
        <circle cx="170" cy="412" r="15" fill={selectedPlayerId === 'W' ? '#0F766E' : '#0B1D28'} stroke="#2DD4BF" strokeWidth="2" />
        <text x="170" y="416" fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">WR</text>
      </g>
      <g onClick={() => onSelectPlayer('W')} className="cursor-pointer">
        <circle cx="830" cy="412" r="15" fill={selectedPlayerId === 'W' ? '#0F766E' : '#0B1D28'} stroke="#2DD4BF" strokeWidth="2" />
        <text x="830" y="416" fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">WR</text>
      </g>

      {/* Dynamic Animated Offensive Backfield */}
      {/* QB */}
      <g onClick={() => onSelectPlayer('QB')} className="cursor-pointer">
        <circle cx={qbX} cy={qbY} r="16" fill={selectedPlayerId === 'QB' ? '#0D9488' : '#115E59'} stroke="#5EEAD4" strokeWidth="2.5" />
        <text x={qbX} y={qbY + 4} fill="#FFFFFF" fontSize="11" fontFamily="monospace" fontWeight="bold" textAnchor="middle">QB</text>
      </g>
      {/* Playside Dive Back */}
      <g onClick={() => onSelectPlayer('RH')} className="cursor-pointer">
        <circle cx={diveX} cy={diveY} r="16" fill={selectedPlayerId === 'RH' ? '#F59E0B' : '#B45309'} stroke="#FDE68A" strokeWidth="2.5" />
        <text x={diveX} y={diveY + 4} fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">DIVE</text>
      </g>
      {/* Backside Pitch Back */}
      <g onClick={() => onSelectPlayer('LH')} className="cursor-pointer">
        <circle cx={pitchX} cy={pitchY} r="16" fill={selectedPlayerId === 'LH' ? '#6366F1' : '#4338CA'} stroke="#C7D2FE" strokeWidth="2.5" />
        <text x={pitchX} y={pitchY + 4} fill="#FFFFFF" fontSize="10" fontFamily="monospace" fontWeight="bold" textAnchor="middle">PITCH</text>
      </g>
    </svg>
  );
};
