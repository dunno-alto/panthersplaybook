import React from 'react';
import { PlayDefinition, TargetSide, OffensiveConcept, DefensiveFrontId, DiveKeyBehavior, PitchKeyBehavior } from '../data/veerPlaybookData';
import { Play, Pause, RotateCcw, StepForward, Eye, Shield, Compass } from 'lucide-react';

interface PlaySetupConsoleProps {
  selectedPlay: PlayDefinition;
  onSelectPlay: (id: string) => void;
  selectedConcept: OffensiveConcept;
  onSelectConcept: (c: OffensiveConcept) => void;
  targetSide: TargetSide;
  onChangeTargetSide: (side: TargetSide) => void;
  zSide: any;
  onChangeZSide: (side: any) => void;
  zType: any;
  onChangeZType: (type: any) => void;
  eleventhMode: any;
  onChangeEleventhMode: (mode: any) => void;
  xMode: any;
  onChangeXMode: (mode: any) => void;
  frontId: DefensiveFrontId;
  onChangeFrontId: (front: DefensiveFrontId) => void;
  diveBehavior: DiveKeyBehavior;
  onChangeDiveBehavior: (b: DiveKeyBehavior) => void;
  pitchBehavior: PitchKeyBehavior;
  onChangePitchBehavior: (b: PitchKeyBehavior) => void;
  powerPassReceiver: any;
  onChangePowerPassReceiver: (r: any) => void;
  onSelectPlayer: (id: string) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  progress: number;
  onResetPreSnap: () => void;
  onStepForward: () => void;
  onStepBackward: () => void;
  isLooping: boolean;
  onToggleLoop: () => void;
  playbackSpeed: number;
  onChangePlaybackSpeed: (s: number) => void;
  currentPhaseNumber: number;
  onJumpToPhase: (range: [number, number]) => void;
  showGapLabels: boolean;
  onToggleGapLabels: () => void;
  showBlockingAngles: boolean;
  onToggleBlockingAngles: () => void;
  chalkboardMode: boolean;
  onToggleChalkboardMode: () => void;
  onClearChalkboard: () => void;
  hasChalkboardDrawings: boolean;
}

export const PlaySetupConsole: React.FC<PlaySetupConsoleProps> = ({
  selectedPlay,
  targetSide,
  onChangeTargetSide,
  frontId,
  onChangeFrontId,
  diveBehavior,
  onChangeDiveBehavior,
  pitchBehavior,
  onChangePitchBehavior,
}) => {
  return (
    <div className="rounded-2xl border border-[#162A33] bg-[#070E13] p-4 lg:p-5 shadow-xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#162A33]/80">
        <div>
          <span className="text-xs font-mono font-bold text-teal-400 uppercase tracking-wider block">
            Offensive Play Console
          </span>
          <h1 className="text-xl sm:text-2xl font-bold text-white font-display">
            {selectedPlay.name}
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400">Play Direction:</span>
          <div className="inline-flex rounded-lg border border-[#162A33] bg-[#050C10] p-0.5 font-mono text-xs">
            <button
              onClick={() => onChangeTargetSide('left')}
              className={`px-3 py-1 rounded font-bold transition-colors cursor-pointer ${
                targetSide === 'left' ? 'bg-teal-400 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              31 Veer (Left)
            </button>
            <button
              onClick={() => onChangeTargetSide('right')}
              className={`px-3 py-1 rounded font-bold transition-colors cursor-pointer ${
                targetSide === 'right' ? 'bg-teal-400 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              22 Veer (Right)
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono">
        <div className="p-3 rounded-xl border border-[#162A33] bg-[#09151D] space-y-2">
          <span className="text-teal-300 font-bold block uppercase">1. Defensive Front</span>
          <div className="flex flex-wrap gap-1.5">
            {(['5-3', '4-4', '6-2', '5-2', '3-4'] as DefensiveFrontId[]).map((f) => (
              <button
                key={f}
                onClick={() => onChangeFrontId(f)}
                className={`px-2 py-1 rounded text-xs transition-all cursor-pointer ${
                  frontId === f ? 'bg-teal-400 text-slate-950 font-bold' : 'bg-[#060D11] text-slate-400 hover:text-white border border-[#162A33]'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div className="p-3 rounded-xl border border-[#162A33] bg-[#09151D] space-y-2">
          <span className="text-amber-300 font-bold block uppercase">2. #1 Dive Key Reaction</span>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => onChangeDiveBehavior('squeeze')}
              className={`px-2.5 py-1 rounded text-xs transition-all cursor-pointer ${
                diveBehavior === 'squeeze' ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-[#060D11] text-slate-400 hover:text-white border border-[#162A33]'
              }`}
            >
              End Crashes (Pull)
            </button>
            <button
              onClick={() => onChangeDiveBehavior('upfield')}
              className={`px-2.5 py-1 rounded text-xs transition-all cursor-pointer ${
                diveBehavior === 'upfield' ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-[#060D11] text-slate-400 hover:text-white border border-[#162A33]'
              }`}
            >
              End Sits (Give)
            </button>
          </div>
        </div>

        <div className="p-3 rounded-xl border border-[#162A33] bg-[#09151D] space-y-2">
          <span className="text-indigo-300 font-bold block uppercase">3. #2 Pitch Key Reaction</span>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => onChangePitchBehavior('commit_qb')}
              className={`px-2.5 py-1 rounded text-xs transition-all cursor-pointer ${
                pitchBehavior === 'commit_qb' ? 'bg-indigo-400 text-slate-950 font-bold' : 'bg-[#060D11] text-slate-400 hover:text-white border border-[#162A33]'
              }`}
            >
              SS OLB Commits to QB (Pitch)
            </button>
            <button
              onClick={() => onChangePitchBehavior('pitch_force')}
              className={`px-2.5 py-1 rounded text-xs transition-all cursor-pointer ${
                pitchBehavior === 'pitch_force' ? 'bg-indigo-400 text-slate-950 font-bold' : 'bg-[#060D11] text-slate-400 hover:text-white border border-[#162A33]'
              }`}
            >
              SS OLB Widens (QB Keep)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
