import React from 'react';
import { X, Printer, Compass } from 'lucide-react';
import { SPECIAL_TEAMS_PLAYBOOK } from '../data/specialTeamsData';

interface SpecialTeamsPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SpecialTeamsPrintModal: React.FC<SpecialTeamsPrintModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#071015] border border-teal-500/40 rounded-2xl w-full max-w-4xl p-6 text-white space-y-6 shadow-2xl my-8">
        <div className="flex items-center justify-between border-b border-[#162A33] pb-4 no-print">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-500/20 text-teal-300 rounded-lg">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-display">
                Special Teams Master Coordinator Call Sheet
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                Printable sideline game-day card for all 6 special teams units
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-4 py-2 bg-teal-400 text-slate-950 font-bold text-xs rounded-xl hover:bg-teal-300 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Print Sheet
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-slate-200 text-xs">
          {Object.values(SPECIAL_TEAMS_PLAYBOOK).map((u) => (
            <div key={u.id} className="p-3.5 rounded-xl border border-[#162A33] bg-[#09151D] space-y-2">
              <div className="flex items-center justify-between border-b border-[#162A33] pb-1.5">
                <span className="font-bold text-teal-300 font-mono">{u.name}</span>
                <span className="text-[10px] text-slate-400 font-mono">{u.targetTempo}</span>
              </div>
              <p className="text-slate-300 font-sans">{u.overview}</p>
              <div className="text-teal-300 italic font-mono text-[11px]">
                Motto: &ldquo;{u.coachingMotto}&rdquo;
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
