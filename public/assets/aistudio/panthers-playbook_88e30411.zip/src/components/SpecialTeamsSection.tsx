import React, { useState } from 'react';
import { SPECIAL_TEAMS_PLAYBOOK, SpecialTeamsUnitId } from '../data/specialTeamsData';
import { Compass, Printer, Users, Shield, Clock } from 'lucide-react';

interface SpecialTeamsSectionProps {
  onOpenPrintModal: () => void;
}

export const SpecialTeamsSection: React.FC<SpecialTeamsSectionProps> = ({ onOpenPrintModal }) => {
  const [selectedUnitId, setSelectedUnitId] = useState<SpecialTeamsUnitId>('kickoff');
  const unit = SPECIAL_TEAMS_PLAYBOOK[selectedUnitId];

  return (
    <div className="rounded-2xl border border-[#162A33] bg-[#070E13] p-5 lg:p-6 shadow-2xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#162A33]">
        <div>
          <span className="text-xs font-mono font-bold text-teal-400 uppercase tracking-wider block">
            Special Teams Coordinator
          </span>
          <h2 className="text-2xl font-bold text-white font-display">
            Special Teams Master Playbook
          </h2>
        </div>
        <button
          onClick={onOpenPrintModal}
          className="px-3.5 py-1.5 rounded-lg bg-teal-500/20 text-teal-300 border border-teal-500/40 text-xs font-mono font-bold hover:bg-teal-500/30 transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Printer className="w-3.5 h-3.5" />
          Print ST Sheet
        </button>
      </div>

      <div className="flex flex-wrap gap-2">
        {Object.values(SPECIAL_TEAMS_PLAYBOOK).map((u) => (
          <button
            key={u.id}
            onClick={() => setSelectedUnitId(u.id)}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all cursor-pointer ${
              selectedUnitId === u.id
                ? 'bg-teal-400 text-slate-950 shadow'
                : 'bg-[#09151D] text-slate-400 border border-[#162A33] hover:text-white'
            }`}
          >
            {u.shortName}
          </button>
        ))}
      </div>

      <div className="p-4 rounded-xl border border-[#162A33] bg-[#09151D] space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-white font-display">{unit.name}</h3>
          <span className="text-xs font-mono text-amber-300">{unit.targetTempo}</span>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">{unit.overview}</p>
        <div className="text-xs text-teal-300 italic font-mono pt-1">
          Motto: &ldquo;{unit.coachingMotto}&rdquo;
        </div>
      </div>
    </div>
  );
};
