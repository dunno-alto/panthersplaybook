import React from 'react';
import { X, Printer, Shield } from 'lucide-react';
import { FORMATION_INFO, DEFENSE_PLAYERS } from '../data/defensePrimerData';

interface DefenseWristbandModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DefenseWristbandModal: React.FC<DefenseWristbandModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#071015] border border-teal-500/40 rounded-2xl w-full max-w-4xl p-6 text-white space-y-6 shadow-2xl my-8">
        <div className="flex items-center justify-between border-b border-[#162A33] pb-4 no-print">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-500/20 text-teal-300 rounded-lg">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-display">
                3-4 Defense Primer & Sideline Call Sheet
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                Base · Shield (5-2) · Vanguard · Shell
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-4 py-2 bg-teal-400 text-slate-950 font-bold text-xs rounded-xl hover:bg-teal-300 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Print Sheet
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="space-y-4 text-xs font-mono">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {Object.values(FORMATION_INFO).map((f: any) => (
              <div key={f.id} className="p-3 rounded-lg border border-[#162A33] bg-[#09151D] space-y-1">
                <div className="flex items-center justify-between text-teal-300 font-bold">
                  <span>{f.name}</span>
                  <span className="text-amber-300 text-[11px]">{f.handSignal}</span>
                </div>
                <p className="text-slate-300 text-[11px] font-sans">{f.summary}</p>
                <div className="text-slate-400 text-[10px] pt-1 border-t border-[#162A33]">
                  Doctrine: {f.doctrine}
                </div>
              </div>
            ))}
          </div>

          <div className="p-3.5 rounded-xl border border-teal-500/30 bg-teal-950/20 space-y-2">
            <span className="font-bold text-teal-300 uppercase block">Defensive Gap Non-Negotiables:</span>
            <ul className="list-disc list-inside space-y-1 text-slate-300 font-sans text-[11px]">
              <li><strong>Sam & Rover:</strong> In 5-2 Shield and Vanguard, align 2x0 at the outside offensive lineman on LOS. Set a hard edge.</li>
              <li><strong>Mike & Will:</strong> Stacked at 4.5 yds in Base and Shield. Open gap principle on run!</li>
              <li><strong>Safeties:</strong> In Base/Shield 10-14 yds. In Vanguard walk up to 5 yds. In Shell drop 12-14 yds.</li>
              <li><strong>Linemen in Shell:</strong> Pin ears back and hunt the sack!</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
