import React from 'react';
import { X, Printer, BookOpen } from 'lucide-react';
import { VEER_PLAYBOOK } from '../data/veerPlaybookData';

interface WristbandModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WristbandModal: React.FC<WristbandModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const play = VEER_PLAYBOOK['22-inside-veer'];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-[#071015] border border-teal-500/40 rounded-2xl w-full max-w-4xl p-6 text-white space-y-6 shadow-2xl my-8">
        <div className="flex items-center justify-between border-b border-[#162A33] pb-4 no-print">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-500/20 text-teal-300 rounded-lg">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold font-display">
                Veer Wristband & Sideline Call Card
              </h2>
              <p className="text-xs text-slate-400 font-mono">
                22 / 31 Veer (Inside Veer) Quick Execution Guide
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => window.print()}
              className="px-4 py-2 bg-teal-400 text-slate-950 font-bold text-xs rounded-xl hover:bg-teal-300 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Print Card
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="space-y-4 text-xs font-mono">
          <div className="p-3.5 rounded-xl border border-teal-500/30 bg-[#09151D] space-y-2">
            <span className="text-teal-300 font-bold uppercase text-sm block">
              Core Alignment & Assignment Rules
            </span>
            <ul className="list-disc list-inside space-y-1 text-slate-200">
              <li><strong>OL:</strong> 2-3 FT SPLITS across line.</li>
              <li><strong>BST:</strong> Blocks BS End for 2 seconds then heads to TDA (FS).</li>
              <li><strong>BSG + C:</strong> Double team WS Tackle to WS ILB. MUST secure DT first.</li>
              <li><strong>PSG + PST:</strong> Double team PS Tackle to SS ILB. MUST secure DT first.</li>
              <li><strong>Y (TE):</strong> Blocks down to SS ILB and can release to secure FS once PST assists.</li>
              <li><strong>QB:</strong> Under center low with even feet. 1-ft play side step, WS foot meets PS foot. Ride Dive Back to 45 deg, read PS End. Pull on crash -> attack SS OLB overhang. Only pitch if SS OLB commits.</li>
              <li><strong>Dive Back:</strong> Behind PS Guard 3-4 yds. Butt down, 45 deg back, chest up, light hand. Step 1 outside leg PSG, step 2 splits PSG. High inside elbow pocket. ALWAYS clamp down 100% whether give or fake!</li>
              <li><strong>Pitch Back:</strong> Behind BS Guard 3-4 yds (EVEN with Dive Back). Open parallel, eyes on QB, maintain 3-4x1 pitch ratio. On pitch: plant outside foot, cut North/South!</li>
              <li><strong>WRs:</strong> Center: 3 yds inside numbers | Boundary: On numbers | Field: 5 yds inside numbers. Solid stance, eyes on ball (NO CADENCE). Sell deep vertical, stalk block without holding.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
