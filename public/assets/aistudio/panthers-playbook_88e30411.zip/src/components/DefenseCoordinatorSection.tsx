import React, { useState } from 'react';
import { Shield, Printer, RotateCcw } from 'lucide-react';
import { FORMATION_INFO, DEFENSE_PLAYERS, DefenseFormation, CoverageScheme } from '../data/defensePrimerData';

interface DefenseCoordinatorSectionProps {
  onOpenPrintModal: () => void;
}

export const DefenseCoordinatorSection: React.FC<DefenseCoordinatorSectionProps> = ({ onOpenPrintModal }) => {
  const [formation, setFormation] = useState<DefenseFormation>('base');
  const [coverage, setCoverage] = useState<CoverageScheme>('green');
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>('SAM');

  const selectedPlayer = DEFENSE_PLAYERS.find((p) => p.id === selectedPlayerId) || DEFENSE_PLAYERS[0];
  const activeFormation = FORMATION_INFO[formation];

  return (
    <div className="rounded-2xl border border-[#162A33] bg-[#070E13] p-5 lg:p-6 shadow-2xl space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#162A33]">
        <div>
          <span className="text-xs font-mono font-bold text-teal-400 uppercase tracking-wider block">
            Defensive Coordinator
          </span>
          <h2 className="text-2xl font-bold text-white font-display">
            3-4 to 5-2 Defense Primer & Call Matrix
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenPrintModal}
            className="px-3.5 py-1.5 rounded-lg bg-teal-500/20 text-teal-300 border border-teal-500/40 text-xs font-mono font-bold hover:bg-teal-500/30 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Call Sheet</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
        {(Object.keys(FORMATION_INFO) as DefenseFormation[]).map((fKey) => {
          const f = FORMATION_INFO[fKey];
          const isSel = formation === fKey;
          return (
            <button
              key={fKey}
              onClick={() => setFormation(fKey)}
              className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                isSel ? 'border-teal-400 bg-teal-950 text-white shadow' : 'border-[#162A33] bg-[#09151D] text-slate-400 hover:text-white'
              }`}
            >
              <div className="text-teal-300 font-bold">{f.codeName}</div>
              <div className="text-[10px] text-slate-300 mt-1">{f.name}</div>
              <div className="text-[9.5px] text-amber-300 mt-0.5">{f.handSignal}</div>
            </button>
          );
        })}
      </div>

      {/* Players grid */}
      <div className="p-4 rounded-xl border border-[#162A33] bg-[#0A1318] space-y-3">
        <span className="text-xs font-mono uppercase text-slate-400 block font-bold">11 Defensive Players:</span>
        <div className="flex flex-wrap gap-1.5">
          {DEFENSE_PLAYERS.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelectedPlayerId(p.id)}
              className={`px-2.5 py-1 text-xs font-mono rounded-lg border transition-colors cursor-pointer ${
                selectedPlayerId === p.id ? 'bg-teal-400 text-slate-950 font-bold border-teal-400' : 'bg-[#060D11] text-slate-400 border-[#162A33] hover:text-white'
              }`}
            >
              {p.id}
            </button>
          ))}
        </div>

        <div className="p-4 rounded-xl border border-[#162A33] bg-[#070E13] space-y-2 text-xs">
          <div className="flex items-center justify-between border-b border-[#162A33] pb-2">
            <span className="text-base font-bold text-white font-display">{selectedPlayer.name} ({selectedPlayer.id})</span>
            <span className="text-teal-300 font-mono">{selectedPlayer.sequentialTechCode}</span>
          </div>
          <div className="text-slate-300 leading-relaxed font-sans">
            <strong>Assignment in {activeFormation.name}: </strong>
            {formation === 'base' && selectedPlayer.baseAssignment}
            {formation === 'shield' && selectedPlayer.shieldAssignment}
            {formation === 'vanguard' && selectedPlayer.vanguardAssignment}
            {formation === 'shell' && selectedPlayer.shellAssignment}
          </div>
        </div>
      </div>
    </div>
  );
};
