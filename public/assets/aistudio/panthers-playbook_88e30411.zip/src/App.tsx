import React, { useEffect, useState, useRef } from 'react';
import {
  BookOpen,
  Compass,
  Maximize2,
  Minimize2,
  Pause,
  PenTool,
  Play,
  Printer,
  RotateCcw,
  Shield,
  StepForward,
  Zap,
} from 'lucide-react';
import {
  DEFENSIVE_FRONTS,
  DefensiveFrontId,
  DiveKeyBehavior,
  EleventhPlayerMode,
  OffensiveConcept,
  PitchKeyBehavior,
  Point,
  PowerPassReceiverOption,
  TargetSide,
  VEER_PLAYBOOK,
  XPlayerMode,
  ZAlignmentSide,
  ZAlignmentType,
  getActivePlayDefinition,
  getBaseOffensiveAlignment,
} from './data/veerPlaybookData';
import { TacticalFieldCanvas, CoachNotation } from './components/TacticalFieldCanvas';
import { PlaySetupConsole } from './components/PlaySetupConsole';
import { WristbandModal } from './components/WristbandModal';
import { DrillsSection } from './components/DrillsSection';
import { DefenseCoordinatorSection } from './components/DefenseCoordinatorSection';
import { SpecialTeamsSection } from './components/SpecialTeamsSection';
import { DefenseWristbandModal } from './components/DefenseWristbandModal';
import { SpecialTeamsPrintModal } from './components/SpecialTeamsPrintModal';

export type AppActiveTab = 'offense' | 'defense' | 'special_teams';

export default function App() {
  const [activeTab, setActiveTab] = useState<AppActiveTab>('offense');
  const [selectedPlayId, setSelectedPlayId] = useState<string>('22-inside-veer');
  const [concept, setConcept] = useState<OffensiveConcept>('inside_veer');
  const [targetSide, setTargetSide] = useState<TargetSide>('right');
  const [zSide, setZSide] = useState<ZAlignmentSide>('right');
  const [zType, setZType] = useState<ZAlignmentType>('wide');
  const [frontId, setFrontId] = useState<DefensiveFrontId>('5-3');
  const [diveBehavior, setDiveBehavior] = useState<DiveKeyBehavior>('squeeze');
  const [pitchBehavior, setPitchBehavior] = useState<PitchKeyBehavior>('commit_qb');
  const [eleventhMode, setEleventhMode] = useState<EleventhPlayerMode>('wide_z');
  const [xMode, setXMode] = useState<XPlayerMode>('tight_x');
  const [powerPassReceiver, setPowerPassReceiver] = useState<PowerPassReceiverOption>('whip');

  // Animation & playback state
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(0.5);
  const [isLooping, setIsLooping] = useState<boolean>(true);

  // Field appearance & chalkboard
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>('RH');
  const [showGapLabels, setShowGapLabels] = useState<boolean>(true);
  const [showBlockingAngles, setShowBlockingAngles] = useState<boolean>(true);
  const [chalkboardMode, setChalkboardMode] = useState<boolean>(false);
  const [customOffsets, setCustomOffsets] = useState<Record<string, Point>>({});
  const [customArrows, setCustomArrows] = useState<CoachNotation[]>([]);
  const [offensePenColor, setOffensePenColor] = useState<string>('#FACC15');
  const [offensePenMode, setOffensePenMode] = useState<'freehand' | 'arrow'>('freehand');

  // Modals
  const [isWristbandOpen, setIsWristbandOpen] = useState<boolean>(false);
  const [isDefenseWristbandOpen, setIsDefenseWristbandOpen] = useState<boolean>(false);
  const [isSpecialTeamsPrintOpen, setIsSpecialTeamsPrintOpen] = useState<boolean>(false);

  const activePlay = getActivePlayDefinition(
    concept,
    targetSide,
    xMode,
    'right',
    'tight',
    zSide,
    zType,
    'none',
    powerPassReceiver
  );
  const activeFront = DEFENSIVE_FRONTS[frontId] || DEFENSIVE_FRONTS['5-3'];

  // Smooth animation loop
  useEffect(() => {
    if (!isPlaying) return;
    let animationFrameId: number;
    let lastTime = performance.now();
    const animate = (now: number) => {
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;
      const deltaProgress = (dt * playbackSpeed) / 3.0;
      setProgress((prev) => {
        const next = prev + deltaProgress;
        if (next >= 1) {
          if (isLooping) return 0;
          setIsPlaying(false);
          return 1;
        }
        return next;
      });
      animationFrameId = requestAnimationFrame(animate);
    };
    animationFrameId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying, playbackSpeed, isLooping]);

  const handleTogglePlay = () => {
    if (progress >= 0.98) {
      setProgress(0);
      setIsPlaying(true);
    } else {
      setIsPlaying((prev) => !prev);
    }
  };

  const currentPhase =
    activePlay.coachingPhases.find(
      (ph) => progress >= ph.timeRange[0] && progress <= ph.timeRange[1]
    ) || activePlay.coachingPhases[0];

  const selectedOffensiveRule =
    activePlay.positionRules[selectedPlayerId] || activePlay.positionRules.RH;

  return (
    <div className="min-h-screen bg-[#05090C] text-[#F8FAFC] flex flex-col selection:bg-teal-500/30 selection:text-white">
      {/* Header */}
      <header className="flex flex-col md:flex-row items-center justify-between gap-4 px-4 sm:px-6 py-3 border-b border-[#162A33] bg-[#060D11]/95 sticky top-0 z-40 no-print backdrop-blur-md">
        <div className="flex items-center justify-between w-full md:w-auto">
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('offense');
            }}
            className="text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 font-display flex items-center gap-2"
          >
            <span className="text-teal-400">12U Panthers Playbook</span>
          </a>
          <div className="md:hidden flex items-center gap-1">
            <button
              onClick={() => setActiveTab('offense')}
              className={`px-2 py-1 text-xs font-bold rounded ${
                activeTab === 'offense' ? 'bg-teal-400 text-slate-950' : 'text-slate-400'
              }`}
            >
              Offense
            </button>
            <button
              onClick={() => setActiveTab('defense')}
              className={`px-2 py-1 text-xs font-bold rounded ${
                activeTab === 'defense' ? 'bg-teal-400 text-slate-950' : 'text-slate-400'
              }`}
            >
              Defense
            </button>
            <button
              onClick={() => setActiveTab('special_teams')}
              className={`px-2 py-1 text-xs font-bold rounded ${
                activeTab === 'special_teams' ? 'bg-teal-400 text-slate-950' : 'text-slate-400'
              }`}
            >
              Special
            </button>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-2 bg-[#09151C] p-1 rounded-xl border border-[#162A33]">
          <button
            onClick={() => setActiveTab('offense')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'offense'
                ? 'bg-teal-400 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-[#0E212B]'
            }`}
          >
            <span>Offense (Veer)</span>
          </button>
          <button
            onClick={() => setActiveTab('defense')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'defense'
                ? 'bg-teal-400 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-[#0E212B]'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Defense (3-4/5-2)</span>
          </button>
          <button
            onClick={() => setActiveTab('special_teams')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'special_teams'
                ? 'bg-teal-400 text-slate-950 shadow-sm'
                : 'text-slate-300 hover:text-white hover:bg-[#0E212B]'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Special Teams</span>
          </button>
        </nav>

        <div className="flex items-center gap-2 shrink-0">
          {activeTab === 'offense' && (
            <button
              onClick={() => setIsWristbandOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-teal-400 rounded-lg hover:bg-teal-300 transition-colors cursor-pointer whitespace-nowrap shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Veer Card</span>
            </button>
          )}
          {activeTab === 'defense' && (
            <button
              onClick={() => setIsDefenseWristbandOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-teal-400 rounded-lg hover:bg-teal-300 transition-colors cursor-pointer whitespace-nowrap shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print 3-4/5-2 Sheet</span>
            </button>
          )}
          {activeTab === 'special_teams' && (
            <button
              onClick={() => setIsSpecialTeamsPrintOpen(true)}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-bold text-slate-950 bg-teal-400 rounded-lg hover:bg-teal-300 transition-colors cursor-pointer whitespace-nowrap shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print ST Sheet</span>
            </button>
          )}
        </div>
      </header>

      {/* Main Workspace */}
      <main className="max-w-[1400px] w-full mx-auto px-4 sm:px-6 py-6 space-y-8 flex-1">
        {activeTab === 'offense' && (
          <div className="space-y-8">
            <PlaySetupConsole
              selectedPlay={activePlay}
              onSelectPlay={() => {}}
              selectedConcept={concept}
              onSelectConcept={setConcept}
              targetSide={targetSide}
              onChangeTargetSide={setTargetSide}
              zSide={zSide}
              onChangeZSide={setZSide}
              zType={zType}
              onChangeZType={setZType}
              eleventhMode={eleventhMode}
              onChangeEleventhMode={setEleventhMode}
              xMode={xMode}
              onChangeXMode={setXMode}
              frontId={frontId}
              onChangeFrontId={setFrontId}
              diveBehavior={diveBehavior}
              onChangeDiveBehavior={setDiveBehavior}
              pitchBehavior={pitchBehavior}
              onChangePitchBehavior={setPitchBehavior}
              powerPassReceiver={powerPassReceiver}
              onChangePowerPassReceiver={setPowerPassReceiver}
              onSelectPlayer={setSelectedPlayerId}
              isPlaying={isPlaying}
              onTogglePlay={handleTogglePlay}
              progress={progress}
              onResetPreSnap={() => { setProgress(0); setIsPlaying(false); }}
              onStepForward={() => setProgress((p) => Math.min(1, p + 0.15))}
              onStepBackward={() => setProgress((p) => Math.max(0, p - 0.15))}
              isLooping={isLooping}
              onToggleLoop={() => setIsLooping((p) => !p)}
              playbackSpeed={playbackSpeed}
              onChangePlaybackSpeed={setPlaybackSpeed}
              currentPhaseNumber={currentPhase.phase}
              onJumpToPhase={(r) => setProgress(r[1])}
              showGapLabels={showGapLabels}
              onToggleGapLabels={() => setShowGapLabels((p) => !p)}
              showBlockingAngles={showBlockingAngles}
              onToggleBlockingAngles={() => setShowBlockingAngles((p) => !p)}
              chalkboardMode={chalkboardMode}
              onToggleChalkboardMode={() => setChalkboardMode((p) => !p)}
              onClearChalkboard={() => { setCustomOffsets({}); setCustomArrows([]); }}
              hasChalkboardDrawings={Object.keys(customOffsets).length > 0 || customArrows.length > 0}
            />

            {/* Tactical Field Canvas */}
            <section className="rounded-2xl border border-[#162A33] bg-[#070E13] p-4 lg:p-6 shadow-2xl space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#162A33]/80">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono font-bold text-teal-400 uppercase tracking-wider">
                    Interactive Field Simulator
                  </span>
                  {isPlaying ? (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-mono text-[11px] font-bold animate-pulse">
                      <Play className="w-3 h-3 fill-emerald-300" /> LIVE SIMULATION
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#0A1318] border border-[#162A33] text-slate-400 font-mono text-[11px]">
                      <Pause className="w-3 h-3" /> PAUSED ({Math.round(progress * 100)}%)
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleTogglePlay}
                    className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-teal-400 text-slate-950 hover:bg-teal-300 transition-all cursor-pointer shadow-sm"
                  >
                    {isPlaying ? 'Pause' : 'Play Simulation'}
                  </button>
                  <button
                    onClick={() => setShowBlockingAngles((p) => !p)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono border transition-colors ${
                      showBlockingAngles ? 'border-teal-400 bg-teal-950/60 text-teal-300' : 'border-[#162A33] bg-[#0A1318] text-slate-400'
                    }`}
                  >
                    Blocks {showBlockingAngles ? 'ON' : 'OFF'}
                  </button>
                </div>
              </div>

              <div className="relative w-full aspect-[16/10] bg-[#050C10] rounded-xl border border-[#162A33] overflow-hidden">
                <TacticalFieldCanvas
                  play={activePlay}
                  frontId={frontId}
                  diveBehavior={diveBehavior}
                  pitchBehavior={pitchBehavior}
                  eleventhMode={eleventhMode}
                  xMode={xMode}
                  zSide={zSide}
                  targetSide={targetSide}
                  progress={progress}
                  fieldTheme="night_turf"
                  selectedPlayerId={selectedPlayerId}
                  onSelectPlayer={setSelectedPlayerId}
                  showGapLabels={showGapLabels}
                  showBlockingAngles={showBlockingAngles}
                  chalkboardMode={chalkboardMode}
                  customOffsets={customOffsets}
                  onUpdateCustomOffset={(pid, pt) => setCustomOffsets((prev) => ({ ...prev, [pid]: pt }))}
                  customArrows={customArrows}
                  onAddCustomArrow={(arr) => setCustomArrows((prev) => [...prev, arr])}
                  penMode={offensePenMode}
                  penColor={offensePenColor}
                />
              </div>

              {/* Progress Slider */}
              <div className="p-3 bg-[#0A1318] border border-[#162A33] rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span>Phase {currentPhase.phase}: <strong className="text-teal-400">{currentPhase.title}</strong></span>
                  <span className="text-teal-300 font-bold">{Math.round(progress * 100)}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={progress}
                  onChange={(e) => {
                    setIsPlaying(false);
                    setProgress(parseFloat(e.target.value));
                  }}
                  className="w-full accent-teal-400 cursor-pointer h-2 bg-[#14262E] rounded-lg"
                />
              </div>
            </section>

            {/* Read Progression & Decision Matrix */}
            <section className="rounded-2xl border border-[#162A33] bg-[#070E13] p-5 lg:p-6 shadow-2xl space-y-4">
              <div className="border-b border-[#162A33]/80 pb-3 flex flex-col sm:flex-row sm:items-end justify-between gap-2">
                <div>
                  <p className="text-xs text-teal-400 font-mono uppercase tracking-wider font-semibold">
                    Veer Progression Keys
                  </p>
                  <h2 className="text-2xl font-bold text-white font-display">
                    Quarterback Decision Matrix
                  </h2>
                </div>
                <span className="text-xs text-slate-400 font-mono">
                  Primary Key: Playside End | Pitch Key: SS OLB/Overhang
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
                <div className="p-4 rounded-xl border border-teal-500/30 bg-[#09151D] space-y-2">
                  <span className="text-teal-300 font-bold block">1. End Crashes (PULL)</span>
                  <p className="text-slate-300 leading-relaxed font-sans">{activePlay.qbDecisionMatrix.crashPull}</p>
                </div>
                <div className="p-4 rounded-xl border border-[#162A33] bg-[#081217] space-y-2">
                  <span className="text-amber-300 font-bold block">2. End Sits / Upfield (GIVE)</span>
                  <p className="text-slate-300 leading-relaxed font-sans">{activePlay.qbDecisionMatrix.squeezeGive}</p>
                </div>
                <div className="p-4 rounded-xl border border-[#162A33] bg-[#081217] space-y-2">
                  <span className="text-indigo-300 font-bold block">3. Pitch Key Overhang (KEEP/PITCH)</span>
                  <p className="text-slate-300 leading-relaxed font-sans">{activePlay.qbDecisionMatrix.pitchPhase}</p>
                </div>
              </div>
            </section>

            {/* Position Assignment Inspector */}
            <section className="rounded-2xl border border-[#162A33] bg-[#070E13] p-5 lg:p-6 shadow-2xl space-y-4">
              <div className="border-b border-[#162A33]/80 pb-3 flex flex-col sm:flex-row sm:items-end justify-between gap-2">
                <div>
                  <p className="text-xs text-teal-400 font-mono uppercase tracking-wider font-semibold">
                    Position Detail: {selectedOffensiveRule.fullName}
                  </p>
                  <h2 className="text-2xl font-bold text-white font-display">
                    Technique & Assignment Rule
                  </h2>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {Object.keys(activePlay.positionRules).map((pid) => (
                    <button
                      key={pid}
                      onClick={() => setSelectedPlayerId(pid)}
                      className={`px-2.5 py-1 text-xs font-mono font-bold rounded-lg border transition-colors cursor-pointer ${
                        selectedPlayerId === pid
                          ? 'bg-teal-400 text-slate-950 border-teal-400'
                          : 'bg-[#091318] text-slate-400 border-[#162A33] hover:text-white'
                      }`}
                    >
                      {pid}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                <div className="p-3.5 rounded-xl bg-[#091318] border border-[#162A33] space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400 font-semibold block">Split & Stance</span>
                  <div className="text-slate-200 font-bold">{selectedOffensiveRule.split}</div>
                  <div className="text-slate-400 text-[11px]">{selectedOffensiveRule.stance}</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#091318] border border-[#162A33] space-y-1">
                  <span className="text-[10px] font-mono uppercase text-slate-400 font-semibold block">Aiming Point & Footwork</span>
                  <div className="text-slate-200 font-bold">{selectedOffensiveRule.aimingPoint}</div>
                  <div className="text-slate-400 text-[11px]">{selectedOffensiveRule.footwork}</div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#091318] border border-teal-500/30 space-y-1 md:col-span-2">
                  <span className="text-[10px] font-mono uppercase text-teal-400 font-semibold block">Assignment vs {activeFront.name}</span>
                  <div className="text-slate-200 leading-relaxed font-sans">{selectedOffensiveRule.assignmentsByFront[frontId]}</div>
                  <div className="text-[11px] font-mono text-teal-300 pt-1">
                    Cue: &ldquo;{selectedOffensiveRule.coachingCue}&rdquo;
                  </div>
                </div>
              </div>
            </section>

            {/* Drills Section */}
            <DrillsSection />
          </div>
        )}

        {/* TAB 2: DEFENSE */}
        {activeTab === 'defense' && (
          <DefenseCoordinatorSection onOpenPrintModal={() => setIsDefenseWristbandOpen(true)} />
        )}

        {/* TAB 3: SPECIAL TEAMS */}
        {activeTab === 'special_teams' && (
          <SpecialTeamsSection onOpenPrintModal={() => setIsSpecialTeamsPrintOpen(true)} />
        )}
      </main>

      <footer className="border-t border-[#162A33] py-6 px-6 text-xs text-slate-400 no-print bg-[#04080B] text-center">
        12U Panthers Playbook & Sideline Coordinator | Split Back Veer System
      </footer>

      {/* Modals */}
      <WristbandModal isOpen={isWristbandOpen} onClose={() => setIsWristbandOpen(false)} />
      <DefenseWristbandModal isOpen={isDefenseWristbandOpen} onClose={() => setIsDefenseWristbandOpen(false)} />
      <SpecialTeamsPrintModal isOpen={isSpecialTeamsPrintOpen} onClose={() => setIsSpecialTeamsPrintOpen(false)} />
    </div>
  );
}
